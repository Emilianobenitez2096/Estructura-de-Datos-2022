def h1(titulo : str) -> None:
    vacio = ""
    print(f"{vacio:*^60}")
    print(f"{titulo:*^60}")
    print(f"{vacio:*^60}")
    
def h2(titulo : str) -> None:
    print(f"{titulo:*^60}")