from LinkedStackExt import LinkedStackExt

def impresion():
    print("-"*25)
    
# creo la pila.
stack = LinkedStackExt()

# asigno valores del 1 al 10.
impresion()
for i in range(1, 11):
        stack.push(i)   
print("** Agrego valores del 1-10 **\n",stack)

# quito 5 valores
impresion()
stack.multi_pop(5)
print("** Elimino 5 valores de la pila **\n",stack)

# remplazo el valor 2 por el 9.
impresion()
stack.replace_all(2,9)
print("** Remplazo el valor 2 por el 9 **\n",stack)

# intercambio el ultimo valor por el primero.
impresion()
stack.exchange()
print("** Intercambio el ultimo valor por el primero **\n",stack)

# muestro resultado final.
impresion()
print("** Resultado final **\n",stack)

