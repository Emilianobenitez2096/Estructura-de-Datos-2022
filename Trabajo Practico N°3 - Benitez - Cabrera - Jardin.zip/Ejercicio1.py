import re

num_tel = ["(0345) 154123456", 
           "+5493454123456", 
           "3454123456", 
           "+54011123456", 
           "34564123456"]

patron = "^\(0345\)\s154.*$|^\+5493454.*$|^3454.*$"

for elem in num_tel:
    match = re.match(patron, elem)
    if match:
        print (f"Numero valido: {match.group()}")