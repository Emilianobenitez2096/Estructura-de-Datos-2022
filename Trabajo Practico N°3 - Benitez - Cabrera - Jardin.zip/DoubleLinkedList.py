from typing import Any, Iterator
from python_ed_fcad_uner_main.data_structures.linear.lists.linked_list import LinkedList
from DoubleLinkedListAbstract import DoubleLinkedListAbstract
from Nodo import Nodo

class DoubleLinkedList(DoubleLinkedListAbstract, LinkedList):

    def __len__(self) -> int:
        return self._size

    def __getitem__(self, key: int) -> Any:
        if self.is_empty():
            raise Exception("Lista vacía. Operación no soportada")
        else:
            if (key <= self._size):
                posicion = 0
                actual = self._header
                for x in range(self._size):
                    if (posicion == key):
                        return actual.element
                    actual = actual.next
                    posicion += 1
            else:
                raise Exception("Indice fuera de rango")

    def __setitem__(self, key: int, value: Any) -> None:
        if self.is_empty():
            raise Exception("Lista vacía. Operación no soportada")
        else:
            if (key <= self._size):
                posicion = 0
                actual = self._header
                for x in range(self._size):
                    if (posicion == key):
                        actual.element = value
                    actual = actual.next
                    posicion += 1
            else:
                raise Exception("Indice fuera de rango")

    def __delitem__(self, key: int) -> None:
        if self.is_empty():
            raise Exception("Lista vacía. Operación no soportada")
        else:
            if (key < self._size):
                posicion = 0
                previo = None
                actual = self._header
                for x in range(self._size):
                    if (posicion == key):
                       break
                    previo = actual 
                    actual = actual.next
                    posicion += 1
                if previo: 
                    previo.next = actual.next
                else:
                    self._header = actual.next
                self._size -= 1
            else:
                raise Exception("Indice fuera de rango")

    def __iter__(self) -> Iterator[Any]:
        actual = self._header
        while actual:
            yield actual.element
            actual = actual.next

    def __str__(self) -> str:
        if self.is_empty():
            return "DoubleLinkedList()"

        resultado = ""
   
        actual = self._header
        while actual != None:
            resultado += str(actual.element) + ", "
            actual = actual.next 
         
        resultado = resultado[:len(resultado)-2]
        
        return f"DoubleLinkedList({resultado})"

    def is_empty(self) -> bool:
        return self._size == 0

    def append(self, elem: Any) -> None:
        nuevo_nodo = Nodo(elem)
        if self.is_empty():
            self._header = nuevo_nodo
        else:
            actual = self._header
            while actual.next:
                actual = actual.next

            actual.next = nuevo_nodo
            actual.next.prev = actual
        self._size += 1
