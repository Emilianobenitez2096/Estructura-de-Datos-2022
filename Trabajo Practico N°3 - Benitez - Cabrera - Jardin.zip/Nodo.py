from typing import Any
from ctypes import Union

class Nodo():
    def __init__(self, element : Any, next = None, prev = None) -> None:
        self.element = element
        self.next : Union[Nodo,None] = next
        self.prev : Union[Nodo,None] = prev