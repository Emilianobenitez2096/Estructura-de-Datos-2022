from python_ed_fcad_uner_main.data_structures.linear.stacks import LinkedStack
from LinkedStackExtAbstract import LinkedStackExtAbstract
from typing import Any, List

class LinkedStackExt(LinkedStack, LinkedStackExtAbstract):
        
    def multi_pop(self, num: int) -> List[Any]:
        if not (self.is_empty()):
            # recorro la pila.
            for x in range(num):
                # quito la ultima posicion.
                self.pop()
        else:
            raise Exception("Pila vacía. Operación no soportada")
    
    def replace_all(self, param1: Any, param2: Any) -> None:
        if not (self.is_empty()):
            # posicion actual.
            actual = self._head
            for x in range(self._size):
                # valor de la posicion actual.
                valor = actual.element
                if valor == param1:
                    actual.element = param2
                actual = actual.next 
        else:
            raise Exception("Pila vacía. Operación no soportada")
    
    def exchange(self) -> None:
        if not (self.is_empty()):
            # posicion actual.
            actual = self._head
            posicion = self._size
            for x in range(self._size):
                # si es la primera posicion le asigno el tope.
                if (posicion == 1):
                    actual.element = self.top()
                actual = actual.next
                # resto una posicion.
                posicion -= 1
        else:
            raise Exception("Pila vacía. Operación no soportada")

