from itertools import count
from typing import Counter
from Deque import Deque

def impresion():
    print("-"*25)

lista1 = Deque()

#Devuelve si la lista esta vacia
print("¿Lista vacia?\n",lista1.is_empty())
impresion()

#Agrega elementos al principio
print("** Agrega elementos al principio **")
for i in range(5):
    lista1.add_first(i)
print(lista1)
impresion()

#Agrega elementos al final
print("** Agrega elementos al final **")
for i in range(6, 11):
    lista1.add_last(i)
print(lista1)
impresion()

#Devuelve el primer elemento de la lista
print("Primer elemento:", lista1.first())
impresion()

#Devuelve el ultimo elemento de la lista
print("Ultimo elemento:", lista1.last())
impresion()

#Elimina el primer elemento
lista1.delete_first()
print("** Elimina el primer elemento **\n",lista1)
impresion()

#Elimina el ultimo elemento
lista1.delete_last()
print("** Elimina el ultimo elemento **\n",lista1)
impresion()

#Devuelve el primer elemento de la lista
print("Primer elemento nuevo:", lista1.first())
impresion()

#Devuelve el ultimo elemento de la lista
print("Ultimo elemento nuevo:", lista1.last())
impresion()

