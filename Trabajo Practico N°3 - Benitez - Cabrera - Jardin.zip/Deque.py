from typing import Any
from DequeAbstract import DequeAbstract
from typing import Any, Union
from python_ed_fcad_uner_main.data_structures.linear import ListNode

class Deque(DequeAbstract):

    def __init__(self) -> None:
        """Crea una pila vacía"""
        self._head : Union[ListNode, None] = None
        self._back : Union[ListNode, None] = None
        self._size : int = 0

    def __len__(self) -> int:
        return self._size
    
    def __str__(self) -> str:
        
        if self.is_empty():
            return "Deque()"

        resultado = "" 
    
        actual = self._head
        while actual != None:
            resultado += str(actual.element) + ", "
            actual = actual.next 
          
        resultado = resultado[:len(resultado)-2]
        
        return f"Deque({resultado})"
    
    def is_empty(self) -> bool:
        return self._size == 0
    
    def first(self) -> Any:
        if self.is_empty():
            raise Exception("Pila vacía. Operación no soportada")
        
        return self._head.element
    
    def last(self) -> Any:
        if self.is_empty():
            raise Exception("Pila vacía. Operación no soportada")
        
        return self._back.element
    
    def add_first(self, element : Any) -> None:
        nuevo_nodo = ListNode(element)
        if self.is_empty():
            self._head = nuevo_nodo
            self._back = nuevo_nodo
        else:
            nuevo_nodo.next = self._head
            self._head = nuevo_nodo
        self._size += 1
        
    
    def add_last(self, element : Any) -> None:
        nuevo_nodo = ListNode(element)
        if self.is_empty():
            self._head = nuevo_nodo
            self._back = nuevo_nodo
        else:
            self._back.next = nuevo_nodo
            self._back = nuevo_nodo
        self._size += 1
    
    def delete_first(self) -> None:
        if not (self.is_empty()):
            self._head = self._head.next
            self._size -= 1
        else:
            raise Exception("Pila vacía. Operación no soportada")
            
    
    def delete_last(self) -> None:
        if not (self.is_empty()):
            
            indice = 1
            previo = None
            actual = self._head
            while actual:
                if indice == self._size:
                    break
                previo = actual
                actual = actual.next
                indice += 1
            if previo: 
                previo.next = actual.next
                self._back = previo
            else:
                self._head.next = actual.next
        
            self._size -= 1
        else:
            raise Exception("Pila vacía. Operación no soportada")
