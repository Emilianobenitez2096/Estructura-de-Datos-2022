from DoubleLinkedList import DoubleLinkedList

def impresion():
    print("-"*25)

# creo la lista.
lista = DoubleLinkedList()

#uso el iterador.
for i in range(10):
    #Agrega elementos a la lista.
    lista.append(i*2)

#pregunto si la lista esta vacia.
print("* ¿Lista vacia?\n",lista.is_empty())
impresion()

#Muestro la lista.
print("** Muestro la lista **\n",lista)
impresion()

# tamaño de la lista.
print("* El tamaño de la lista es:",len(lista))
impresion()

# devuelve el elemento ubicado en la posicion 5.
print("* Elemento numero 5:",lista[5])
impresion()

# modifico el elemento ubicado en la posicion 6.
print("* Lista original:\n",lista)
lista[6] = 55
print("* Lista con elemento de posicion 6 cambiado:\n",lista)
impresion()


# elimino el elemento ubicado en la posicion 2.
print("* Lista original:\n",lista)
del lista[2]
print("* Lista con elemento de posicion 2 eliminado:\n",lista)